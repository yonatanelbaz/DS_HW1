#ifndef WORLDCUP
#define WORLDCUP
#include "worldcup23a1.h"
#define WIN 3
#define PLAYERS 11
#define TIE 1
using namespace std;
world_cup_t::world_cup_t():
    playersIdTree(Player::compare_playerID),
    teamsTree(Team::compare_TeamID),
    playerGoalsTree(Player::compare_playerGoals),
    validTeamsTree(Team::compare_TeamID),
    sumPlayers(0),
    topScorer(nullptr){}


world_cup_t::~world_cup_t()
{
	// TODO: Your code goes here
}


// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
StatusType world_cup_t::add_team(int teamId, int points)
{
    if(teamId<0 || points<0) {
        return StatusType::INVALID_INPUT;
    }
    try {
        std::shared_ptr<Team> newTeam(new Team(teamId, points));

        if (this->teamsTree.Find(newTeam) != nullptr) {
            return StatusType::FAILURE;
        }

        StatusType ret_status = this->teamsTree.Insert(newTeam);
        return ret_status;
    }
    catch(const std::exception& e) {
        return StatusType::ALLOCATION_ERROR;
    }
}

// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!????????????
StatusType world_cup_t::remove_team(int teamId) /////
{
    bool removed;
    if(teamId<=0) {
        return StatusType::INVALID_INPUT;
    }
    try{
        std::shared_ptr<Team> tempTeam =  std::shared_ptr<Team>(new Team(teamId, 0));
        auto tempTeamNode = this -> teamsTree.Find(tempTeam);
        if(tempTeamNode == nullptr) {
            return StatusType::FAILURE;
        }
        if(!tempTeamNode -> GetValue() -> getPlayersById() -> IsEmpty()) {
            return StatusType::FAILURE;
        }
        removed = teamsTree.Remove(tempTeam);

        if(removed) {
            return StatusType::SUCCESS;
        }
        return StatusType::FAILURE;
    }
    catch(const std::exception& e){
        return StatusType::ALLOCATION_ERROR;
    }


}


// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
StatusType world_cup_t::add_player(int playerId, int teamId, int gamesPlayed, int goals, int cards, bool goalKeeper)
{
    std::shared_ptr<Player> temp_above;
    std::shared_ptr<Player> temp_below;

    if((goals<0 || gamesPlayed<0 || teamId<=0 || playerId<=0 || cards<0) || (gamesPlayed==0 && (goals>0 || cards>0))) {
        return StatusType::INVALID_INPUT;
    }
    try {
        shared_ptr<Player> newPlayer = shared_ptr<Player>(new Player(playerId, gamesPlayed, goals, cards, goalKeeper));
        shared_ptr<Team> newTeam = shared_ptr<Team>(new Team(teamId, 0));

        auto newTeamNode = this->teamsTree.Find(newTeam);
        auto newPlayerNode = this -> playersIdTree.Find(newPlayer);
        if (newPlayerNode != nullptr || newTeamNode == nullptr) {
            return StatusType::FAILURE;
        }
        auto dadNode = this->playerGoalsTree.FindDad(newPlayer);

        if(Player::compare_playerGoals(dadNode -> GetValue(), newPlayer) == 1){
            temp_above = dadNode -> GetValue();
            temp_below = dadNode -> GetValue()-> getClosestBelow();
        }
        else{
            temp_above = dadNode -> GetValue() -> getClosestAbove();
            temp_below = dadNode -> GetValue();
        }
        if(temp_above != nullptr) {temp_above -> setClosestBelow(newPlayer);}
        if(temp_below != nullptr) {temp_below -> setClosestAbove(newPlayer);}
        newPlayer -> setClosestAbove(temp_above);
        newPlayer -> setClosestBelow(temp_below);


        StatusType ret_status = this->playersIdTree.Insert(newPlayer);
        if (ret_status != StatusType::SUCCESS) {
            return ret_status;
        }
        ret_status = this->playerGoalsTree.Insert(newPlayer);
        if (ret_status != StatusType::SUCCESS) {
            return ret_status;
        }
        ret_status = newTeamNode -> GetValue() -> getPlayersById() -> Insert(newPlayer);
        if (ret_status != StatusType::SUCCESS) {
            return ret_status;
        }
        ret_status = newTeamNode -> GetValue() -> getPlayersByGoals() -> Insert(newPlayer);
        if (ret_status != StatusType::SUCCESS) {
            return ret_status;
        }
        // TODO: Your code goes here
        auto playerTeam = newTeamNode->GetValue();
        if(Player::compare_playerGoals(playerTeam -> getTopScorer(), newPlayer) == -1){
            playerTeam -> setTopScorer(newPlayer);
        }
        if(Player::compare_playerGoals(this -> topScorer, newPlayer) == -1){
            this -> topScorer = newPlayer;
        }
        playerTeam->incNumPlayers();
        newPlayer -> updateTeam();
        //playerTeam->setSumGoals(playerTeam->getSumGoals() + goals);
        //playerTeam->setSumCards(playerTeam->getSumCards() + cards);
        newPlayer-> setGamesPlayed(newPlayer->getGamesPlayed() - playerTeam -> getGamesPlayed());

        if (goalKeeper == true) {
            playerTeam->incGoalKeepers();
        }
        bool before = playerTeam->getTeamValid();
        if (playerTeam->getNumPlayers() >= PLAYERS && playerTeam->getGoalkeepers() > 0) {
            playerTeam->setTeamValid(true);
        }
        if(!before && playerTeam->getTeamValid()){
            validTeamsTree.Insert(playerTeam);
        }
        this->sumPlayers++;
        return StatusType::SUCCESS;
    }
    catch(const std::exception& e){
        return StatusType:: ALLOCATION_ERROR;
    }
}

StatusType world_cup_t::remove_player(int playerId)
{
	// TODO: Your code goes here
    this->sumPlayers--;
	return StatusType::SUCCESS;
}

StatusType world_cup_t::update_player_stats(int playerId, int gamesPlayed,
                                            int scoredGoals, int cardsReceived)
{
    StatusType result;
    if(playerId<=0 || gamesPlayed<0 || scoredGoals<0 || cardsReceived<0) {
        return StatusType::INVALID_INPUT;
    }
    try {
        shared_ptr<Player> newPlayer = shared_ptr<Player>(new Player(playerId, gamesPlayed, scoredGoals, cardsReceived, 0));
        auto player = this->playersIdTree.Find(newPlayer);
        if (player == nullptr) {
            return StatusType::FAILURE;
        }
        newPlayer = player-> GetValue();
        newPlayer -> update(gamesPlayed, scoredGoals, cardsReceived);

        result = remove_player(playerId);
        if(result != StatusType::SUCCESS){return result;}

        result = add_player(playerId, newPlayer -> getTeamId(), gamesPlayed, scoredGoals, cardsReceived, newPlayer -> getGoalKeeper());

        return result;
    }
    catch (const std::exception& e){
        return StatusType::ALLOCATION_ERROR;
    }
}

StatusType world_cup_t::play_match(int teamId1, int teamId2)
{
    if(teamId1 == teamId2 || teamId1<=0 || teamId2<=0) {
        return StatusType::INVALID_INPUT;
    }
    shared_ptr<Team> t1 = this->teamsTree.find(teamId1);
    if(t1 == nullptr || t1->getTeamValid() == false) {
        return StatusType::FAILURE;
    }
    shared_ptr<Team> t2 = this->teamsTree.find(teamId2);
    if(t2 == nullptr || t2->getTeamValid() ==false) {
        return StatusType::FAILURE;
    }
    int result1 = t1->getPoints() + t1->getSumGoals() - t1->getSumCards();
    int result2 = t2->getPoints() + t2->getSumGoals() - t2->getSumCards();
    if(result1==result2) {
        t1->setNumPoints(t1->getPoints()+TIE);
        t2->setNumPoints(t2->getPoints()+TIE);
    } else {
        if(result1>result2) {
            t1->setNumPoints(t1->getPoints()+WIN);
        } else {
            t2->setNumPoints(t2->getPoints()+WIN);
        }
    }
	// TODO: Your code goes here+
    /////need to update playergame
	return StatusType::SUCCESS;
}


// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
output_t<int> world_cup_t::get_num_played_games(int playerId)
{
    if(playerId <= 0) {
        return StatusType::INVALID_INPUT;
    }
    try {
        shared_ptr<Player> tempPlayer = shared_ptr<Player>(new Player(playerId, 0, 0, 0, 0));
        auto tempPlayerNode = this->playersIdTree.Find(tempPlayer);
        if (tempPlayerNode == nullptr) {
            return StatusType::FAILURE;
        }
        return (tempPlayerNode->GetValue()->getGamesPlayed() + tempPlayerNode->GetValue()->getTeam()->getGamesPlayed());
    }
    catch (const std::exception& e) {
        return StatusType::ALLOCATION_ERROR;
    }
}

// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
output_t<int> world_cup_t::get_team_points(int teamId)
{
    if(teamId <= 0) {
        return StatusType::INVALID_INPUT;
    }
    try{
        shared_ptr<Team> tempTeam = shared_ptr<Team>(new Team(teamId, 0));
        auto tempTeamNode = this -> teamsTree.Find(tempTeam);
        if(tempTeamNode == nullptr) {
            return StatusType::FAILURE;
        }
        return tempTeamNode -> GetValue() -> getPoints();
    }
    catch(const std::exception& e){
        return StatusType::ALLOCATION_ERROR;
    }

}

StatusType world_cup_t::unite_teams(int teamId1, int teamId2, int newTeamId)
{
	// TODO: Your code goes here
	return StatusType::SUCCESS;
}

// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
output_t<int> world_cup_t::get_top_scorer(int teamId)
{
    if(teamId == 0) {
        return StatusType::INVALID_INPUT;
    }
    if(teamId<0) {
        return this->topScorer->getPlayerId();
    }
    try{
        shared_ptr<Team> tempTeam = shared_ptr<Team>(new Team(teamId, 0));
        auto tempTeamNode = this -> teamsTree.Find(tempTeam);
        if(tempTeamNode == nullptr) {
            return StatusType::FAILURE;
        }
        //return
        return tempTeamNode-> GetValue() -> getTopScorer() -> getPlayerId();
        // TODO: Your code goes here
    }
    catch (const std::exception& e){
        return StatusType::ALLOCATION_ERROR;
    }

}

// TODO : Nothing Elbaz did already no touching!!!!!!!!!!!!!!!!!!!!!!!!!
output_t<int> world_cup_t::get_all_players_count(int teamId)
{
    if(teamId == 0) {
        return StatusType::INVALID_INPUT;
    }
    if(teamId<0) {
        return this->sumPlayers;

    }
    try {
        shared_ptr<Team> tempTeam = shared_ptr<Team>(new Team(teamId, 0));
        auto tempTeamNode = this->teamsTree.Find(tempTeam);
        if (tempTeamNode == nullptr) {
            return StatusType::FAILURE;
        }
        return tempTeamNode->GetValue()->getNumPlayers();
    }
    catch(const std::exception& e){
        return StatusType::ALLOCATION_ERROR;
    }
}

StatusType world_cup_t::get_all_players(int teamId, int *const output)
{
	// TODO: Your code goes here
    output[0] = 4001;
    output[1] = 4002;
	return StatusType::SUCCESS;
}

output_t<int> world_cup_t::get_closest_player(int playerId, int teamId)
{
	// TODO: Your code goes here
	return 1006;
}

output_t<int> world_cup_t::knockout_winner(int minTeamId, int maxTeamId)
{
	// TODO: Your code goes here
	return 2;
}

#endif